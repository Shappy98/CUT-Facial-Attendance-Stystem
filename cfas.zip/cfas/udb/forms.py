from django import forms

from udb.models import CustomUser, Modules
class DateInput(forms.DateInput):
    input_type = "date"

class AddUser(forms.Form):
    username=forms.CharField(label="Username",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    email=forms.EmailField(label="Email",max_length=50,widget=forms.EmailInput(attrs={"class":"form-control"}))
    password=forms.CharField(label="Password",max_length=50,widget=forms.PasswordInput(attrs={"class":"form-control"}))
    first_name=forms.CharField(label="First Name",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    last_name=forms.CharField(label="Last Name",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    user_types=(
        (1,"Admin"),
        (2,"Lecturer"),
        (3,"Student")
    )
    user_type=forms.ChoiceField(label="User Type",choices=user_types,widget=forms.Select(attrs={"class":"form-control"}))

 
class AddModulesForm(forms.Form):
    module_code=forms.CharField(label="Module Code",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    module_name=forms.CharField(label="Module Name",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    lecturer=forms.CharField(label="Lecturer",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    numberofstudents=forms.CharField(label="Number of Students",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))