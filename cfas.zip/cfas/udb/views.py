from django.shortcuts import render,redirect
from udb.forms import AddUser,AddModulesForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from udb.models import Modules,CustomUser, Present
from recognition.views import view_attendance_rephome
import csv

# Create your views here.
def register(request):
	if request.user.username!='admin':
		return redirect('not-authorised')
	if request.method=='POST':
		form=AddUser(request.POST,request.FILES)
		if form.is_valid():
			first_name=form.cleaned_data["first_name"]
			last_name=form.cleaned_data["last_name"]
			username=form.cleaned_data["username"]
			email=form.cleaned_data["email"]
			password=form.cleaned_data["password"]
			user_type=form.cleaned_data["user_type"]
		
		try:
			user=CustomUser.objects.create_user(username=username,password=password,email=email,last_name=last_name,first_name=first_name,user_type=user_type)
			user.save()
			messages.success(request, f'User registered successfully!')
			return redirect('dashboard')
		except:
			messages.error(request,"Failed to register User")
			return redirect('dashboard')
			
	else:
		form=AddUser(request.POST)
		return render(request, "users/register.html", {"form": form})

def add_module(request):
	if request.user.username!='admin':
		return redirect('not-authorised')
	if request.method=='POST':
		form=AddModulesForm(request.POST)
		if form.is_valid():
			a=form.cleaned_data
			b=Modules( module_code = a['module_code'],
                module_name =a['module_name'],
				lecturer=a['lecturer'],
				numberofstudents=a['numberofstudents'],		
		
				)
			b.save()
			messages.success(request, f'Module registered successfully!')
			return redirect('dashboard')
	else:
		form=AddModulesForm()
	return render(request,"manage/add_modules.html",{'form': form})

def excelexport(request):
	present_list=Present.objects.filter(module_id='CUIT 406')
	
	return render(request,"manage/excellexport.html",{'present_list':present_list})

def att_csv(request):
	
	response=HttpResponse(content_type='text/csv')
	response['Content-Disposition']='attachment: filename=attendance.csv'
	writer=csv.writer(response)
	writer.writerow(['Date','Present','Module Code','ID'])

	attreps=Present.objects.all()

	for attrep in attreps:
		writer.writerow([attrep.date,attrep.present,attrep.module_id,attrep.user_id])
	return response

def mymodules(request):
	mymodules=Modules.objects.filter(lecturer=str(request.user.first_name)+' '+str(request.user.last_name))
	
	return render(request,"manage/mymodules.html",{'mymodules':mymodules})
