from django.apps import AppConfig


class UdbConfig(AppConfig):
    name = 'udb'
