from django.contrib import admin

# Register your models here.
from django.contrib.auth.admin import UserAdmin
from udb.models import CustomUser,Modules,Time,Present,AdminHOD

class UserModel(UserAdmin):
    pass

admin.site.register(CustomUser,UserModel)
admin.site.register(Present)
admin.site.register(Modules)
admin.site.register(AdminHOD)
admin.site.register(Time)