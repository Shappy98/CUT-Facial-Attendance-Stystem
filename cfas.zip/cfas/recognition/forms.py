from django.forms import ModelForm
from django.contrib.auth.models import User
from django import forms
from udb.models import Modules
#from django.contrib.admin.widgets import AdminDateWidget

class usernameForm(forms.Form):
	username=forms.CharField(max_length=30)



class DateForm(forms.Form):
	date=forms.DateField(widget = forms.SelectDateWidget(empty_label=("Choose Year", "Choose Month", "Choose Day")))


class UsernameAndDateForm(forms.Form):
	username=forms.CharField(max_length=30)
	date_from=forms.DateField(widget = forms.SelectDateWidget(empty_label=("Choose Year", "Choose Month", "Choose Day")))
	date_to=forms.DateField(widget = forms.SelectDateWidget(empty_label=("Choose Year", "Choose Month", "Choose Day")))


class DateForm_2(forms.Form):
	date_from=forms.DateField(widget = forms.SelectDateWidget(empty_label=("Choose Year", "Choose Month", "Choose Day")))
	date_to=forms.DateField(widget = forms.SelectDateWidget(empty_label=("Choose Year", "Choose Month", "Choose Day")))


class SelectMod(forms.Form):
	modules=Modules.objects.all()
	modules_list=[]
	for module in modules:
		one_module=(module.module_code,module.module_name)
		modules_list.append(one_module)
	module_code=forms.ChoiceField(label="Module",choices=modules_list,widget=forms.Select(attrs={"class":"form-control"}))

    
class SelectModRep(forms.Form):
	modules=Modules.objects.all()
	modules_list=[]
	for module in modules:
		one_module=(module.module_code,module.module_name)
		modules_list.append(one_module)
	module_code=forms.ChoiceField(label="Module",choices=modules_list,widget=forms.Select(attrs={"class":"form-control"}))

class SelectModGraph(forms.Form):
	modules=Modules.objects.all()
	modules_list=[]
	for module in modules:
		one_module=(module.module_code,module.module_name)
		modules_list.append(one_module)
	module_code=forms.ChoiceField(label="Module",choices=modules_list,widget=forms.Select(attrs={"class":"form-control"}))
