"""cfas URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib.auth.views import logout
from django.urls import path
from chat import views as chat_views
from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from recognition import views as recog_views
from udb import views as users_views
from django.contrib.auth.views import logout
from django.urls import path
from chat import views as chat_view
urlpatterns = [

    

    path('', recog_views.home, name='home'),
    
    path('attend_lect/', recog_views.attend_lect, name='attend_lect'),
    path('sol/', recog_views.sol, name='sol'),
    path('report/', recog_views.report, name='report'),
    path('reporth/', recog_views.view_attendance_rephome, name='reporth'),
    path('chat_i', chat_views.index, name='chat_i'),
    path('rep/', users_views.excelexport, name='rep'),
    path('cs_v/', users_views.att_csv, name='cs_v'),
     path('mymodu/', users_views.mymodules, name='mymodu'),


    path('mess_i/', chat_views.index, name='mess_i'),
    path('chat/', chat_views.chat_view, name='chats'),
    path('chat/<int:sender>/<int:receiver>/', chat_view.message_view, name='chat'),
    path('api/messages/<int:sender>/<int:receiver>/', chat_view.message_list, name='message-detail'),
    path('api/messages/', chat_view.message_list, name='message-list'),


    path('dashboard/', recog_views.dashboard, name='dashboard'),
    path('train/', recog_views.train, name='train'),
    path('add_photos/', recog_views.add_photos, name='add-photos'),
    path('add_modules/',users_views.add_module,name="add_modules"),
    path('login/',auth_views.LoginView.as_view(template_name='users/login.html'),name='login'),
    path('logout/',auth_views.LogoutView.as_view(template_name='recognition/home.html'),name='logout'),
    path('register/', users_views.register, name='register'),
    path('mark_your_attendance', recog_views.mark_your_attendance ,name='mark-your-attendance'),
    path('mark_your_attendance_out', recog_views.mark_your_attendance_out ,name='mark-your-attendance-out'),
    path('view_attendance_home', recog_views.view_attendance_home ,name='view-attendance-home'),
    path('graph_view/', recog_views.graph_view  ,name='graph_view'),
    path('graphselect/', recog_views.selectGraphRep  ,name='graphselect'),


      
    path('view_attendance_date', recog_views.view_attendance_date ,name='view-attendance-date'),
    path('view_attendance_student', recog_views.view_attendance_student ,name='view-attendance-student'),
    path('view_my_attendance', recog_views.view_my_attendance_student_login ,name='view-my-attendance-student-login'),
    path('not_authorised', recog_views.not_authorised, name='not-authorised')



    
     

]